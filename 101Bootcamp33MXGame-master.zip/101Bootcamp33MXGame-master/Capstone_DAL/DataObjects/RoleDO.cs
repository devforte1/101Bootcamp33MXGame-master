﻿

namespace Capstone_DAL.DataObjects
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    //For use later in other methods
    public class RoleDO
    {
        public int roleID;
        public string roleName;
    }
}

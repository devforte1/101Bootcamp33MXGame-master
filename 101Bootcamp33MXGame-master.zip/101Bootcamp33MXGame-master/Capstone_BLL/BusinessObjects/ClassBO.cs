﻿

namespace Capstone_BLL.BusinessObjects
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class ClassBO
    {
        public string className;
        public int classID;
        public int classArmor;
        public int classDamage;
        public int classStamina;
        public int classMagica;
        public int baseHP;
    }
}

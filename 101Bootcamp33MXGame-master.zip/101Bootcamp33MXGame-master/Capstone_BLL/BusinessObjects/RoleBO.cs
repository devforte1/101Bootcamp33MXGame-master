﻿

namespace Capstone_BLL.BusinessObjects
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    //For holding role values across object types
    public class RoleBO
    {
        public int roleID;
        public string roleName;


    }
}

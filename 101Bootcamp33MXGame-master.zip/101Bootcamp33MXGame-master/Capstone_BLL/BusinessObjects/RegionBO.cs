﻿

namespace Capstone_BLL.BusinessObjects
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    /// <summary>
    /// Ony for storing region data between do and bo
    /// </summary>
    public class RegionBO
    {
        public string regionName;
        public int danger;
        public int hasShop;
        public int regionID;
        public string regionDesc;

    }
}

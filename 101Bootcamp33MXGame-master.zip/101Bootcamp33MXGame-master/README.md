# 101Bootcamp33MXGame


STEPS FOR INSTALLING

1. RUNNING XGame.sql. Do this with SSMS and you will have to modify the path on for "FILENAME" to where .mdf and .ldf will be create. The wrong path will cause errors.

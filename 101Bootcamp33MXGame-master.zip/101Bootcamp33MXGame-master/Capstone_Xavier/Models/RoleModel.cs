﻿
namespace Capstone_Xavier.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    //For holding values across role object types
    public class RoleModel
    {
        public int roleID { get; set; }
        public string roleName { get; set; }
    }
}
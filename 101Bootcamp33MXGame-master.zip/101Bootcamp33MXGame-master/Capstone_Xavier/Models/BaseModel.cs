﻿

namespace Capstone_Xavier.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    public class BaseModel
    {
        public int alertType { get; set; }
        public  string alertMessage { get; set; }

    }
}
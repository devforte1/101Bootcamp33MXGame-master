﻿

namespace Capstone_Xavier.Common
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    //For easier readability for armor types using int values
    public enum ArmorTypes
    {
        Cloth = 1, 
        Light_Armor = 2,
        Heavy_Armor = 3
    }
}
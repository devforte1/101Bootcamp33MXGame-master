﻿

namespace Capstone_Xavier.Common
{


    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    //For telling the item type in code. Easier to read than int
    public enum ItemTypes
    {
        Health = 0,
        Stamina = 1, 
        Magica = 2,
        Armor = 3,
        Weapons = 4
     
    }


}
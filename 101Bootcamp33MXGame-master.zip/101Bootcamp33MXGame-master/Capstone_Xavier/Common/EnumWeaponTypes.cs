﻿

namespace Capstone_Xavier.Common
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    //For readability on different weapon types based on int value
    public enum WeaponTypes {
        Daggers = 1,
        Short_Swords = 2,
        Swords = 3,
        Hammers_Maces = 4,
        Axes = 5, 
        Staves = 6,
        Scrolls_Books = 7,
        Thrown_Bows = 8
    }
}
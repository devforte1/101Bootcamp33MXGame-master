﻿
namespace Capstone_Xavier.Common
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    //For easier readability for class types.
    public enum Classes
    {
        Hunter = 3, 
        Warrior = 4, 
        Thief = 5, 
        Mage = 6, 
        Paladin = 7, 
        Ranger = 8
    }
}